package com.rei.buildedition;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class SleepMonitorService extends Service {
    public static volatile boolean running=false;
    private AudioRecord recorder;
    private Thread worker;
    private final int sampleRate=16000;
    private final int buffer=AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);

    @Override public void onCreate() {
        super.onCreate();
        NotificationChannel ch = new NotificationChannel("rei_sleep","REI Сон",NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);
        Notification n = new Notification.Builder(this,"rei_sleep")
            .setContentTitle("REI: мониторинг сна")
            .setContentText("Автоматическое определение речи включено")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build();
        startForeground(7,n);
    }

    @Override public int onStartCommand(Intent intent,int flags,int id) {
        if ("STOP".equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (!running) startMonitor();
        return START_STICKY;
    }

    private void startMonitor() {
        running=true;
        recorder=new AudioRecord(MediaRecorder.AudioSource.MIC,sampleRate,
            AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,buffer*2);
        worker=new Thread(() -> {
            short[] data=new short[buffer];
            try {
                recorder.startRecording();
                long last=0;
                while(running) {
                    int n=recorder.read(data,0,data.length);
                    if(n<=0) continue;
                    double sum=0;
                    for(int i=0;i<n;i++){ double x=data[i]; sum+=x*x; }
                    double rms=Math.sqrt(sum/n);
                    // Speech-like event: sustained amplitude above a conservative threshold.
                    if(rms>1100 && System.currentTimeMillis()-last>15000) {
                        saveWav(data,n);
                        last=System.currentTimeMillis();
                    }
                }
            } catch(Exception ignored) {}
            try { recorder.stop(); } catch(Exception ignored) {}
            recorder.release();
        });
        worker.start();
    }

    private void saveWav(short[] pcm,int count) {
        File dir=new File(getExternalFilesDir(null),"sleep_records");
        if(!dir.exists()) dir.mkdirs();
        File f=new File(dir,"speech_"+System.currentTimeMillis()+".wav");
        try(FileOutputStream out=new FileOutputStream(f)){
            writeWavHeader(out,count*2);
            ByteBuffer b=ByteBuffer.allocate(count*2).order(ByteOrder.LITTLE_ENDIAN);
            for(int i=0;i<count;i++) b.putShort(pcm[i]);
            out.write(b.array());
        } catch(Exception ignored) {}
    }

    private void writeWavHeader(OutputStream out,int dataLen)throws IOException{
        int byteRate=sampleRate*2;
        out.write(new byte[]{'R','I','F','F'});
        writeLE(out,36+dataLen,4); out.write(new byte[]{'W','A','V','E','f','m','t',' '});
        writeLE(out,16,4); writeLE(out,1,2); writeLE(out,1,2); writeLE(out,sampleRate,4);
        writeLE(out,byteRate,4); writeLE(out,2,2); writeLE(out,16,2); out.write(new byte[]{'d','a','t','a'}); writeLE(out,dataLen,4);
    }
    private void writeLE(OutputStream o,int v,int bytes)throws IOException{ for(int i=0;i<bytes;i++)o.write((v>>(8*i))&255); }

    @Override public void onDestroy(){ running=false; if(worker!=null)try{worker.join(500);}catch(Exception ignored){}; super.onDestroy(); }
    @Override public IBinder onBind(Intent i){ return null; }
}