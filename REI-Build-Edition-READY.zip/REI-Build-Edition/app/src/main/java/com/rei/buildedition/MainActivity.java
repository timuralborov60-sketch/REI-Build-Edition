package com.rei.buildedition;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;
    private static final int REQ = 10;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.status);
        Button sleep = findViewById(R.id.sleep);
        sleep.setOnClickListener(v -> toggleSleep());
        if (getIntent().getBooleanExtra("stop", false)) status.setText("Мониторинг остановлен");
    }

    private void toggleSleep() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ);
            return;
        }
        Intent i = new Intent(this, SleepMonitorService.class);
        if (SleepMonitorService.running) {
            i.setAction("STOP");
            stopService(i);
            status.setText("Сон: выключен");
        } else {
            i.setAction("START");
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            status.setText("Сон: включён — слушаю речь");
        }
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r,p,g);
        if (r==REQ && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) toggleSleep();
    }
}