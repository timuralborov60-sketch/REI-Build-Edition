# REI Build Edition
Android/Samsung prototype with a **Сон** button, foreground microphone monitoring and automatic sound-activity detection. When a sound event is detected, a short PCM/WAV fragment is saved in the app's private external files directory.

Important: amplitude detection is not true speech recognition; it can trigger on snoring, music, TV or other loud sounds.
