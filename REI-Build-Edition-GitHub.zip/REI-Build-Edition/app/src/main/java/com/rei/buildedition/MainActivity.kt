package com.rei.buildedition

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 80, 48, 48)
        }
        val title = TextView(this).apply { text = "REI Build Edition"; textSize = 28f }
        val status = TextView(this).apply { text = "Режим «Сон» готов"; textSize = 18f; setPadding(0,30,0,30) }
        val sleep = Button(this).apply { text = "🌙 Включить «Сон»" }
        layout.addView(title); layout.addView(status); layout.addView(sleep)
        setContentView(layout)

        sleep.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            } else {
                ContextCompat.startForegroundService(this, Intent(this, SleepRecorderService::class.java))
                status.text = "🌙 «Сон» включён — слушаю речь"
                sleep.text = "⏹ Остановить «Сон»"
            }
        }
    }
}
