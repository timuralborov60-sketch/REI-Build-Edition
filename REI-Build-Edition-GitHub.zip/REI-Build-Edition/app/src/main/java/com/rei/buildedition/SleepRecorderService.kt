package com.rei.buildedition

import android.app.*
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.IBinder
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.sqrt

class SleepRecorderService : Service() {
    private var audioRecord: AudioRecord? = null
    private var running = false
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel("sleep", "REI Сон", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        val notification = Notification.Builder(this, "sleep")
            .setContentTitle("REI — режим «Сон»")
            .setContentText("Автоматически ищу речь во сне")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(7, notification)
        startVoiceDetection()
    }

    private fun startVoiceDetection() {
        val sampleRate = 16000
        val minBuffer = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer <= 0) return

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC, sampleRate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
            minBuffer * 2
        )
        running = true
        audioRecord!!.startRecording()

        executor.execute {
            val buffer = ShortArray(minBuffer)
            var speechStartedAt = 0L
            var lastVoiceAt = 0L
            var recording = false
            var recorder: MediaRecorder? = null

            while (running) {
                val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                if (read <= 0) continue

                var sum = 0.0
                for (i in 0 until read) {
                    val v = buffer[i].toDouble()
                    sum += v * v
                }
                val rms = sqrt(sum / read)
                val voice = rms > 900.0 // базовый порог; можно сделать настраиваемым
                val now = System.currentTimeMillis()

                if (voice) {
                    if (!recording) {
                        if (speechStartedAt == 0L) speechStartedAt = now
                        if (now - speechStartedAt >= 250) {
                            val dir = File(getExternalFilesDir(null), "sleep").apply { mkdirs() }
                            val file = File(dir, "voice_${now}.m4a")
                            recorder = MediaRecorder(this@SleepRecorderService).apply {
                                setAudioSource(MediaRecorder.AudioSource.MIC)
                                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                                setOutputFile(file.absolutePath)
                                prepare()
                                start()
                            }
                            recording = true
                        }
                    }
                    lastVoiceAt = now
                } else {
                    speechStartedAt = 0L
                    if (recording && now - lastVoiceAt >= 1800) {
                        recorder?.runCatching { stop(); release() }
                        recorder = null
                        recording = false
                    }
                }
            }
            recorder?.runCatching { stop(); release() }
        }
    }

    override fun onDestroy() {
        running = false
        audioRecord?.runCatching { stop(); release() }
        audioRecord = null
        executor.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
