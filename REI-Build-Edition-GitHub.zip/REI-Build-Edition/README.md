# REI Build Edition

Samsung/Android prototype with a **«Сон»** button and basic voice-activity detection.

## Automatic APK build with GitHub

1. Create a GitHub repository and upload this project.
2. Push the files to the `main` branch.
3. Open the **Actions** tab.
4. Select **Build REI APK** and run it if it did not start automatically.
5. When the workflow finishes, open the run and download the artifact **REI-Build-Edition-debug**.
6. Extract the downloaded artifact and install `app-debug.apk` on the Samsung phone.

The current prototype detects voice-like audio by amplitude. It can be triggered by snoring, TV/music, or loud noise. It does not yet transcribe speech.
